#ifndef BUILD_INFO_H
#define BUILD_INFO_H

#define SCFW_BRANCH imx_scfw_2022q4
#define SCFW_BUILD 5624UL
#define SCFW_COMMIT 0x6638c032UL
#define SCFW_DATE "Nov 02 2022"
#define SCFW_DATE2 Nov_02_2022
#define SCFW_TIME "07:48:31"

#endif
