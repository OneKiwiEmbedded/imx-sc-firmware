/*
 * Copyright (c) 2016, Freescale Semiconductor, Inc.
 * Copyright 2017-2022 NXP
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of the copyright holder nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*!
 * File containing hypervisor RPC functions for the SECO service.
 *
 * @addtogroup SECO_SVC
 * @{
 */

/* Includes */

#include "main/types.h"
#include "svc/seco/seco_api.h"
#include "../../main/rpc.h"
#include "svc/seco/seco_rpc.h"

/* Local Defines */

/* Local Types */

/*--------------------------------------------------------------------------*/
/* Translate and forward RPC call                                           */
/*--------------------------------------------------------------------------*/
void seco_xlate(sc_ipc_t ipc, sc_rpc_msg_t *msg)
{
    uint8_t func = RPC_FUNC(msg);
    sc_err_t err = SC_ERR_NONE;

    switch (func)
    {
        case SECO_FUNC_UNKNOWN :
            {
                RPC_SIZE(msg) = 1;
                RPC_R8(msg) = SC_ERR_NOTFOUND;
            }
            break;
        case SECO_FUNC_IMAGE_LOAD :
            {
                sc_err_t result;
                sc_faddr_t addr_src = ((sc_faddr_t) RPC_U64(msg, 0U));
                sc_faddr_t addr_dst = ((sc_faddr_t) RPC_U64(msg, 8U));
                uint32_t len = ((uint32_t) RPC_U32(msg, 16U));
                sc_bool_t fw = U2B(RPC_U8(msg, 20U));

                V2P_ADDR(ipc, &addr_src);
                V2P_ADDR(ipc, &addr_dst);

                result = sc_seco_image_load(ipc, addr_src, addr_dst, len, fw);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case SECO_FUNC_AUTHENTICATE :
            {
                sc_err_t result;
                sc_seco_auth_cmd_t cmd = ((sc_seco_auth_cmd_t) RPC_U8(msg, 8U));
                sc_faddr_t addr = ((sc_faddr_t) RPC_U64(msg, 0U));

                V2P_ADDR(ipc, &addr);

                result = sc_seco_authenticate(ipc, cmd, addr);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case SECO_FUNC_ENH_AUTHENTICATE :
            {
                sc_err_t result;
                sc_seco_auth_cmd_t cmd = ((sc_seco_auth_cmd_t) RPC_U8(msg, 16U));
                sc_faddr_t addr = ((sc_faddr_t) RPC_U64(msg, 0U));
                uint32_t mask1 = ((uint32_t) RPC_U32(msg, 8U));
                uint32_t mask2 = ((uint32_t) RPC_U32(msg, 12U));

                V2P_ADDR(ipc, &addr);

                result = sc_seco_enh_authenticate(ipc, cmd, addr, mask1, mask2);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case SECO_FUNC_FORWARD_LIFECYCLE :
            {
                sc_err_t result;
                uint32_t change = ((uint32_t) RPC_U32(msg, 0U));

                result = sc_seco_forward_lifecycle(ipc, change);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case SECO_FUNC_RETURN_LIFECYCLE :
            {
                sc_err_t result;
                sc_faddr_t addr = ((sc_faddr_t) RPC_U64(msg, 0U));

                V2P_ADDR(ipc, &addr);

                result = sc_seco_return_lifecycle(ipc, addr);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case SECO_FUNC_COMMIT :
            {
                sc_err_t result;
                uint32_t info = ((uint32_t) RPC_U32(msg, 0U));

                result = sc_seco_commit(ipc, &info);

                RPC_R8(msg) = U8(result);
                RPC_U32(msg, 0U) = U32(info);
                RPC_SIZE(msg) = 2U;
            }
            break;
        case SECO_FUNC_ATTEST_MODE :
            {
                sc_err_t result;
                uint32_t mode = ((uint32_t) RPC_U32(msg, 0U));

                result = sc_seco_attest_mode(ipc, mode);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case SECO_FUNC_ATTEST :
            {
                sc_err_t result;
                uint64_t nonce = ((uint64_t) RPC_U64(msg, 0U));

                result = sc_seco_attest(ipc, nonce);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case SECO_FUNC_GET_ATTEST_PKEY :
            {
                sc_err_t result;
                sc_faddr_t addr = ((sc_faddr_t) RPC_U64(msg, 0U));

                V2P_ADDR(ipc, &addr);

                result = sc_seco_get_attest_pkey(ipc, addr);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case SECO_FUNC_GET_ATTEST_SIGN :
            {
                sc_err_t result;
                sc_faddr_t addr = ((sc_faddr_t) RPC_U64(msg, 0U));

                V2P_ADDR(ipc, &addr);

                result = sc_seco_get_attest_sign(ipc, addr);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case SECO_FUNC_ATTEST_VERIFY :
            {
                sc_err_t result;
                sc_faddr_t addr = ((sc_faddr_t) RPC_U64(msg, 0U));

                V2P_ADDR(ipc, &addr);

                result = sc_seco_attest_verify(ipc, addr);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case SECO_FUNC_GEN_KEY_BLOB :
            {
                sc_err_t result;
                uint32_t id = ((uint32_t) RPC_U32(msg, 16U));
                sc_faddr_t load_addr = ((sc_faddr_t) RPC_U64(msg, 0U));
                sc_faddr_t export_addr = ((sc_faddr_t) RPC_U64(msg, 8U));
                uint16_t max_size = ((uint16_t) RPC_U16(msg, 20U));

                V2P_ADDR(ipc, &load_addr);
                V2P_ADDR(ipc, &export_addr);

                result = sc_seco_gen_key_blob(ipc, id, load_addr, export_addr, max_size);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case SECO_FUNC_LOAD_KEY :
            {
                sc_err_t result;
                uint32_t id = ((uint32_t) RPC_U32(msg, 8U));
                sc_faddr_t addr = ((sc_faddr_t) RPC_U64(msg, 0U));

                V2P_ADDR(ipc, &addr);

                result = sc_seco_load_key(ipc, id, addr);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case SECO_FUNC_GET_MP_KEY :
            {
                sc_err_t result;
                sc_faddr_t dst_addr = ((sc_faddr_t) RPC_U64(msg, 0U));
                uint16_t dst_size = ((uint16_t) RPC_U16(msg, 8U));

                V2P_ADDR(ipc, &dst_addr);

                result = sc_seco_get_mp_key(ipc, dst_addr, dst_size);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case SECO_FUNC_UPDATE_MPMR :
            {
                sc_err_t result;
                sc_faddr_t addr = ((sc_faddr_t) RPC_U64(msg, 0U));
                uint8_t size = ((uint8_t) RPC_U8(msg, 8U));
                uint8_t lock = ((uint8_t) RPC_U8(msg, 9U));

                V2P_ADDR(ipc, &addr);

                result = sc_seco_update_mpmr(ipc, addr, size, lock);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case SECO_FUNC_GET_MP_SIGN :
            {
                sc_err_t result;
                sc_faddr_t msg_addr = ((sc_faddr_t) RPC_U64(msg, 0U));
                uint16_t msg_size = ((uint16_t) RPC_U16(msg, 16U));
                sc_faddr_t dst_addr = ((sc_faddr_t) RPC_U64(msg, 8U));
                uint16_t dst_size = ((uint16_t) RPC_U16(msg, 18U));

                V2P_ADDR(ipc, &msg_addr);
                V2P_ADDR(ipc, &dst_addr);

                result = sc_seco_get_mp_sign(ipc, msg_addr, msg_size, dst_addr, dst_size);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case SECO_FUNC_V2X_BUILD_INFO :
            {
                sc_err_t result;
                uint32_t version = ((uint32_t) 0U);
                uint32_t commit = ((uint32_t) 0U);

                result = sc_seco_v2x_build_info(ipc, &version, &commit);

                RPC_R8(msg) = U8(result);
                RPC_U32(msg, 0U) = U32(version);
                RPC_U32(msg, 4U) = U32(commit);
                RPC_SIZE(msg) = 3U;
            }
            break;
        case SECO_FUNC_SET_MONO_COUNTER_PARTITION_HSM :
            {
                sc_err_t result;
                uint16_t she = ((uint16_t) RPC_U16(msg, 0U));
                uint16_t hsm = ((uint16_t) RPC_U16(msg, 2U));

                result = sc_seco_set_mono_counter_partition_hsm(ipc, &she, &hsm);

                RPC_R8(msg) = U8(result);
                RPC_U16(msg, 0U) = U16(she);
                RPC_U16(msg, 2U) = U16(hsm);
                RPC_SIZE(msg) = 2U;
            }
            break;
        case SECO_FUNC_FIPS_INFO :
            {
                sc_err_t result;
                seco_fips_info_t cert = ((seco_fips_info_t) 0U);
                seco_fips_info_t mode = ((seco_fips_info_t) 0U);

                result = sc_seco_fips_info(ipc, &cert, &mode);

                RPC_R8(msg) = U8(result);
                RPC_U8(msg, 0U) = U8(cert);
                RPC_U8(msg, 1U) = U8(mode);
                RPC_SIZE(msg) = 2U;
            }
            break;
        case SECO_FUNC_SET_FIPS_MODE :
            {
                sc_err_t result;
                uint8_t mode = ((uint8_t) RPC_U8(msg, 0U));
                uint32_t reason = ((uint32_t) 0U);

                result = sc_seco_set_fips_mode(ipc, mode, &reason);

                RPC_R8(msg) = U8(result);
                RPC_U32(msg, 0U) = U32(reason);
                RPC_SIZE(msg) = 2U;
            }
            break;
        case SECO_FUNC_FIPS_DEGRADE :
            {
                sc_err_t result;
                sc_faddr_t addr = ((sc_faddr_t) RPC_U64(msg, 0U));
                uint32_t status = ((uint32_t) 0U);

                V2P_ADDR(ipc, &addr);

                result = sc_seco_fips_degrade(ipc, addr, &status);

                RPC_R8(msg) = U8(result);
                RPC_U32(msg, 0U) = U32(status);
                RPC_SIZE(msg) = 2U;
            }
            break;
        case SECO_FUNC_FIPS_KEY_ZERO :
            {
                sc_err_t result;
                sc_faddr_t addr = ((sc_faddr_t) RPC_U64(msg, 0U));

                V2P_ADDR(ipc, &addr);

                result = sc_seco_fips_key_zero(ipc, addr);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case SECO_FUNC_BUILD_INFO :
            {
                uint32_t version = ((uint32_t) 0U);
                uint32_t commit = ((uint32_t) 0U);

                sc_seco_build_info(ipc, &version, &commit);

                RPC_U32(msg, 0U) = U32(version);
                RPC_U32(msg, 4U) = U32(commit);
                RPC_SIZE(msg) = 3U;
            }
            break;
        case SECO_FUNC_CHIP_INFO :
            {
                sc_err_t result;
                uint16_t lc = ((uint16_t) 0U);
                uint16_t monotonic = ((uint16_t) 0U);
                uint32_t uid_l = ((uint32_t) 0U);
                uint32_t uid_h = ((uint32_t) 0U);

                result = sc_seco_chip_info(ipc, &lc, &monotonic, &uid_l, &uid_h);

                RPC_R8(msg) = U8(result);
                RPC_U16(msg, 8U) = U16(lc);
                RPC_U16(msg, 10U) = U16(monotonic);
                RPC_U32(msg, 0U) = U32(uid_l);
                RPC_U32(msg, 4U) = U32(uid_h);
                RPC_SIZE(msg) = 4U;
            }
            break;
        case SECO_FUNC_ENABLE_DEBUG :
            {
                sc_err_t result;
                sc_faddr_t addr = ((sc_faddr_t) RPC_U64(msg, 0U));

                V2P_ADDR(ipc, &addr);

                result = sc_seco_enable_debug(ipc, addr);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case SECO_FUNC_GET_EVENT :
            {
                sc_err_t result;
                uint8_t idx = ((uint8_t) RPC_U8(msg, 0U));
                uint32_t event = ((uint32_t) 0U);

                result = sc_seco_get_event(ipc, idx, &event);

                RPC_R8(msg) = U8(result);
                RPC_U32(msg, 0U) = U32(event);
                RPC_SIZE(msg) = 2U;
            }
            break;
        case SECO_FUNC_FUSE_WRITE :
            {
                sc_err_t result;
                sc_faddr_t addr = ((sc_faddr_t) RPC_U64(msg, 0U));

                V2P_ADDR(ipc, &addr);

                result = sc_seco_fuse_write(ipc, addr);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case SECO_FUNC_PATCH :
            {
                sc_err_t result;
                sc_faddr_t addr = ((sc_faddr_t) RPC_U64(msg, 0U));

                V2P_ADDR(ipc, &addr);

                result = sc_seco_patch(ipc, addr);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case SECO_FUNC_SET_MONO_COUNTER_PARTITION :
            {
                sc_err_t result;
                uint16_t she = ((uint16_t) RPC_U16(msg, 0U));

                result = sc_seco_set_mono_counter_partition(ipc, &she);

                RPC_R8(msg) = U8(result);
                RPC_U16(msg, 0U) = U16(she);
                RPC_SIZE(msg) = 2U;
            }
            break;
        case SECO_FUNC_START_RNG :
            {
                sc_err_t result;
                sc_seco_rng_stat_t status = ((sc_seco_rng_stat_t) 0U);

                result = sc_seco_start_rng(ipc, &status);

                RPC_R8(msg) = U8(result);
                RPC_U32(msg, 0U) = U32(status);
                RPC_SIZE(msg) = 2U;
            }
            break;
        case SECO_FUNC_SAB_MSG :
            {
                sc_err_t result;
                sc_faddr_t addr = ((sc_faddr_t) RPC_U64(msg, 0U));

                V2P_ADDR(ipc, &addr);

                result = sc_seco_sab_msg(ipc, addr);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case SECO_FUNC_CAAM_TD_CONFIG :
            {
                sc_err_t result;
                sc_rsrc_t resource = ((sc_rsrc_t) RPC_U16(msg, 0U));
                sc_bool_t allow = U2B(RPC_U8(msg, 2U));
                sc_bool_t lock = U2B(RPC_U8(msg, 3U));

                V2P_RESOURCE(ipc, &resource);

                result = sc_seco_caam_td_config(ipc, resource, allow, lock);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case SECO_FUNC_SECVIO_ENABLE :
            {
                sc_err_t result;

                result = sc_seco_secvio_enable(ipc);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case SECO_FUNC_SECVIO_CONFIG :
            {
                sc_err_t result;
                uint8_t id = ((uint8_t) RPC_U8(msg, 20U));
                uint8_t access = ((uint8_t) RPC_U8(msg, 21U));
                uint32_t data0 = ((uint32_t) RPC_U32(msg, 0U));
                uint32_t data1 = ((uint32_t) RPC_U32(msg, 4U));
                uint32_t data2 = ((uint32_t) RPC_U32(msg, 8U));
                uint32_t data3 = ((uint32_t) RPC_U32(msg, 12U));
                uint32_t data4 = ((uint32_t) RPC_U32(msg, 16U));
                uint8_t size = ((uint8_t) RPC_U8(msg, 22U));

                result = sc_seco_secvio_config(ipc, id, access, &data0, &data1, &data2, &data3, &data4, size);

                RPC_R8(msg) = U8(result);
                RPC_U32(msg, 0U) = U32(data0);
                RPC_U32(msg, 4U) = U32(data1);
                RPC_U32(msg, 8U) = U32(data2);
                RPC_U32(msg, 12U) = U32(data3);
                RPC_U32(msg, 16U) = U32(data4);
                RPC_SIZE(msg) = 6U;
            }
            break;
        case SECO_FUNC_SECVIO_DGO_CONFIG :
            {
                sc_err_t result;
                uint8_t id = ((uint8_t) RPC_U8(msg, 4U));
                uint8_t access = ((uint8_t) RPC_U8(msg, 5U));
                uint32_t data = ((uint32_t) RPC_U32(msg, 0U));

                result = sc_seco_secvio_dgo_config(ipc, id, access, &data);

                RPC_R8(msg) = U8(result);
                RPC_U32(msg, 0U) = U32(data);
                RPC_SIZE(msg) = 2U;
            }
            break;
        default :
            {
                RPC_SIZE(msg) = 1;
                RPC_R8(msg) = SC_ERR_NOTFOUND;
            }
            break;
    }

    RPC_VER(msg) = SC_RPC_VERSION;
    RPC_SVC(msg) = SC_RPC_SVC_RETURN;
}

/** @} */

