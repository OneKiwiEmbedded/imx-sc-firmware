/*
 * Copyright (c) 2016, Freescale Semiconductor, Inc.
 * Copyright 2017-2022 NXP
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of the copyright holder nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*!
 * File containing hypervisor RPC functions for the MISC service.
 *
 * @addtogroup MISC_SVC
 * @{
 */

/* Includes */

#include "main/types.h"
#include "svc/misc/misc_api.h"
#include "../../main/rpc.h"
#include "svc/misc/misc_rpc.h"

/* Local Defines */

/* Local Types */

/*--------------------------------------------------------------------------*/
/* Translate and forward RPC call                                           */
/*--------------------------------------------------------------------------*/
void misc_xlate(sc_ipc_t ipc, sc_rpc_msg_t *msg)
{
    uint8_t func = RPC_FUNC(msg);
    sc_err_t err = SC_ERR_NONE;

    switch (func)
    {
        case MISC_FUNC_UNKNOWN :
            {
                RPC_SIZE(msg) = 1;
                RPC_R8(msg) = SC_ERR_NOTFOUND;
            }
            break;
        case MISC_FUNC_SET_CONTROL :
            {
                sc_err_t result;
                sc_rsrc_t resource = ((sc_rsrc_t) RPC_U16(msg, 8U));
                sc_ctrl_t ctrl = ((sc_ctrl_t) RPC_U32(msg, 0U));
                uint32_t val = ((uint32_t) RPC_U32(msg, 4U));

                V2P_RESOURCE(ipc, &resource);

                result = sc_misc_set_control(ipc, resource, ctrl, val);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case MISC_FUNC_GET_CONTROL :
            {
                sc_err_t result;
                sc_rsrc_t resource = ((sc_rsrc_t) RPC_U16(msg, 4U));
                sc_ctrl_t ctrl = ((sc_ctrl_t) RPC_U32(msg, 0U));
                uint32_t val = ((uint32_t) 0U);

                V2P_RESOURCE(ipc, &resource);

                result = sc_misc_get_control(ipc, resource, ctrl, &val);

                RPC_R8(msg) = U8(result);
                RPC_U32(msg, 0U) = U32(val);
                RPC_SIZE(msg) = 2U;
            }
            break;
        case MISC_FUNC_SET_MAX_DMA_GROUP :
            {
                sc_err_t result;
                sc_rm_pt_t pt = ((sc_rm_pt_t) RPC_U8(msg, 0U));
                sc_misc_dma_group_t max = ((sc_misc_dma_group_t) RPC_U8(msg, 1U));

                V2P_PT(ipc, &pt);

                result = sc_misc_set_max_dma_group(ipc, pt, max);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case MISC_FUNC_SET_DMA_GROUP :
            {
                sc_err_t result;
                sc_rsrc_t resource = ((sc_rsrc_t) RPC_U16(msg, 0U));
                sc_misc_dma_group_t group = ((sc_misc_dma_group_t) RPC_U8(msg, 2U));

                V2P_RESOURCE(ipc, &resource);

                result = sc_misc_set_dma_group(ipc, resource, group);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case MISC_FUNC_DEBUG_OUT :
            {
                uint8_t ch = ((uint8_t) RPC_U8(msg, 0U));

                sc_misc_debug_out(ipc, ch);

                RPC_SIZE(msg) = 1U;
            }
            break;
        case MISC_FUNC_WAVEFORM_CAPTURE :
            {
                sc_err_t result;
                sc_bool_t enable = U2B(RPC_U8(msg, 0U));

                result = sc_misc_waveform_capture(ipc, enable);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case MISC_FUNC_BUILD_INFO :
            {
                uint32_t build = ((uint32_t) 0U);
                uint32_t commit = ((uint32_t) 0U);

                sc_misc_build_info(ipc, &build, &commit);

                RPC_U32(msg, 0U) = U32(build);
                RPC_U32(msg, 4U) = U32(commit);
                RPC_SIZE(msg) = 3U;
            }
            break;
        case MISC_FUNC_API_VER :
            {
                uint16_t cl_maj = ((uint16_t) 0U);
                uint16_t cl_min = ((uint16_t) 0U);
                uint16_t sv_maj = ((uint16_t) 0U);
                uint16_t sv_min = ((uint16_t) 0U);

                sc_misc_api_ver(ipc, &cl_maj, &cl_min, &sv_maj, &sv_min);

                RPC_U16(msg, 0U) = U16(cl_maj);
                RPC_U16(msg, 2U) = U16(cl_min);
                RPC_U16(msg, 4U) = U16(sv_maj);
                RPC_U16(msg, 6U) = U16(sv_min);
                RPC_SIZE(msg) = 3U;
            }
            break;
        case MISC_FUNC_UNIQUE_ID :
            {
                uint32_t id_l = ((uint32_t) 0U);
                uint32_t id_h = ((uint32_t) 0U);

                sc_misc_unique_id(ipc, &id_l, &id_h);

                RPC_U32(msg, 0U) = U32(id_l);
                RPC_U32(msg, 4U) = U32(id_h);
                RPC_SIZE(msg) = 3U;
            }
            break;
        case MISC_FUNC_SET_ARI :
            {
                sc_err_t result;
                sc_rsrc_t resource = ((sc_rsrc_t) RPC_U16(msg, 0U));
                sc_rsrc_t resource_mst = ((sc_rsrc_t) RPC_U16(msg, 2U));
                uint16_t ari = ((uint16_t) RPC_U16(msg, 4U));
                sc_bool_t enable = U2B(RPC_U8(msg, 6U));

                V2P_RESOURCE(ipc, &resource);
                V2P_RESOURCE(ipc, &resource_mst);

                result = sc_misc_set_ari(ipc, resource, resource_mst, ari, enable);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case MISC_FUNC_BOOT_STATUS :
            {
                sc_misc_boot_status_t status = ((sc_misc_boot_status_t) RPC_U8(msg, 0U));

                sc_misc_boot_status(ipc, status);

                RPC_SIZE(msg) = 0U;
            }
            break;
        case MISC_FUNC_BOOT_DONE :
            {
                sc_err_t result;
                sc_rsrc_t cpu = ((sc_rsrc_t) RPC_U16(msg, 0U));

                V2P_RESOURCE(ipc, &cpu);

                result = sc_misc_boot_done(ipc, cpu);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case MISC_FUNC_OTP_FUSE_READ :
            {
                sc_err_t result;
                uint32_t word = ((uint32_t) RPC_U32(msg, 0U));
                uint32_t val = ((uint32_t) 0U);

                result = sc_misc_otp_fuse_read(ipc, word, &val);

                RPC_R8(msg) = U8(result);
                RPC_U32(msg, 0U) = U32(val);
                RPC_SIZE(msg) = 2U;
            }
            break;
        case MISC_FUNC_OTP_FUSE_WRITE :
            {
                sc_err_t result;
                uint32_t word = ((uint32_t) RPC_U32(msg, 0U));
                uint32_t val = ((uint32_t) RPC_U32(msg, 4U));

                result = sc_misc_otp_fuse_write(ipc, word, val);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case MISC_FUNC_SET_TEMP :
            {
                sc_err_t result;
                sc_rsrc_t resource = ((sc_rsrc_t) RPC_U16(msg, 0U));
                sc_misc_temp_t temp = ((sc_misc_temp_t) RPC_U8(msg, 4U));
                int16_t celsius = ((int16_t) RPC_I16(msg, 2U));
                int8_t tenths = ((int8_t) RPC_I8(msg, 5U));

                V2P_RESOURCE(ipc, &resource);

                result = sc_misc_set_temp(ipc, resource, temp, celsius, tenths);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case MISC_FUNC_GET_TEMP :
            {
                sc_err_t result;
                sc_rsrc_t resource = ((sc_rsrc_t) RPC_U16(msg, 0U));
                sc_misc_temp_t temp = ((sc_misc_temp_t) RPC_U8(msg, 2U));
                int16_t celsius = ((int16_t) 0U);
                int8_t tenths = ((int8_t) 0U);

                V2P_RESOURCE(ipc, &resource);

                result = sc_misc_get_temp(ipc, resource, temp, &celsius, &tenths);

                RPC_R8(msg) = U8(result);
                RPC_I16(msg, 0U) = I16(celsius);
                RPC_I8(msg, 2U) = I8(tenths);
                RPC_SIZE(msg) = 2U;
            }
            break;
        case MISC_FUNC_GET_BOOT_DEV :
            {
                sc_rsrc_t dev = ((sc_rsrc_t) 0U);

                sc_misc_get_boot_dev(ipc, &dev);

                P2V_RESOURCE(ipc, &dev);

                RPC_U16(msg, 0U) = U16(dev);
                RPC_SIZE(msg) = 2U;
            }
            break;
        case MISC_FUNC_GET_BOOT_TYPE :
            {
                sc_err_t result;
                sc_misc_bt_t type = ((sc_misc_bt_t) 0U);

                result = sc_misc_get_boot_type(ipc, &type);

                RPC_R8(msg) = U8(result);
                RPC_U8(msg, 0U) = U8(type);
                RPC_SIZE(msg) = 2U;
            }
            break;
        case MISC_FUNC_GET_BOOT_CONTAINER :
            {
                sc_err_t result;
                uint8_t idx = ((uint8_t) 0U);

                result = sc_misc_get_boot_container(ipc, &idx);

                RPC_R8(msg) = U8(result);
                RPC_U8(msg, 0U) = U8(idx);
                RPC_SIZE(msg) = 2U;
            }
            break;
        case MISC_FUNC_GET_BUTTON_STATUS :
            {
                sc_bool_t status = U2B(0U);

                sc_misc_get_button_status(ipc, &status);

                RPC_U8(msg, 0U) = B2U8(status);
                RPC_SIZE(msg) = 2U;
            }
            break;
        case MISC_FUNC_ROMPATCH_CHECKSUM :
            {
                sc_err_t result;
                uint32_t checksum = ((uint32_t) 0U);

                result = sc_misc_rompatch_checksum(ipc, &checksum);

                RPC_R8(msg) = U8(result);
                RPC_U32(msg, 0U) = U32(checksum);
                RPC_SIZE(msg) = 2U;
            }
            break;
        case MISC_FUNC_BOARD_IOCTL :
            {
                sc_err_t result;
                uint32_t parm1 = ((uint32_t) RPC_U32(msg, 0U));
                uint32_t parm2 = ((uint32_t) RPC_U32(msg, 4U));
                uint32_t parm3 = ((uint32_t) RPC_U32(msg, 8U));

                result = sc_misc_board_ioctl(ipc, &parm1, &parm2, &parm3);

                RPC_R8(msg) = U8(result);
                RPC_U32(msg, 0U) = U32(parm1);
                RPC_U32(msg, 4U) = U32(parm2);
                RPC_U32(msg, 8U) = U32(parm3);
                RPC_SIZE(msg) = 4U;
            }
            break;
        default :
            {
                RPC_SIZE(msg) = 1;
                RPC_R8(msg) = SC_ERR_NOTFOUND;
            }
            break;
    }

    RPC_VER(msg) = SC_RPC_VERSION;
    RPC_SVC(msg) = SC_RPC_SVC_RETURN;
}

/** @} */

